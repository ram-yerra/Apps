<?php get_header(); ?>

	<div id="content">
<?php is_tag(); ?>
		<?php if (have_posts()) : ?>

 	  <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
 	  <?php /* If this is a category archive */ if (is_category()) { ?>
		<h2 class="pagetitle"><?php single_cat_title(); ?></h2>
 	  <?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
		<h2 class="pagetitle">Articles about <?php single_tag_title(); ?>&#8217;</h2>
 	  <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
		<h2 class="pagetitle"><?php the_time('F jS Y'); ?> Archives</h2>
 	  <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
		<h2 class="pagetitle"><?php the_time('F Y'); ?> Archives</h2>
 	  <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
		<h2 class="pagetitle"><?php the_time('Y'); ?> Archives</h2>
	  <?php /* If this is an author archive */ } elseif (is_author()) { ?>
		<h2 class="pagetitle">Author Archive</h2>
 	  <?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
		<h2 class="pagetitle">Blog Archives</h2>
 	  <?php } ?>


		<?php while (have_posts()) : the_post(); ?>
		<div class="post">
				<h3><span><?php the_time('M j, Y') ?></span></h3>
				<h4 id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
			<?php $values = get_post_custom_values("catimage");
				if (isset($values[0])) { ?>
					<a href="<?php the_permalink() ?>" rel="bookmark"><img src="<?php $values = get_post_custom_values("catimage"); echo $values[0]; ?>" alt="<?php the_title(); ?>" class="cat-image"/></a>
				<?php } ?>
			<small>Posted by <?php the_author_posts_link('namefl'); ?> in <?php the_category(', ') ?>
			<span class="comments-info"> &bull; <?php comments_popup_link('No comments', '1 comment', '% comments '); ?></span></small>
				<div class="entry">
					<?php the_excerpt() ?>
				</div>

				

<br />
			</div>

		<?php endwhile; ?>
		<div class="navigation">
			<div class="alignleft"><?php next_posts_link('Previous entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Next entries') ?></div>
		</div>
	<?php else : ?>

		<h2 class="center">Not found</h2>

	<?php endif; ?>
	</div>
<?php get_sidebar(); ?>

<?php get_footer(); ?>
