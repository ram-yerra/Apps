<div id="sidebar">
	<ul id="sidelist">
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar()) : endif; ?>
	</ul><!-- #sidelist --> 
</div><!-- #sidebar -->
