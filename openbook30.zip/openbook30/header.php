<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php if (is_home () ) { bloginfo('name'); }
elseif ( is_category() ) { single_cat_title(); echo ' - ' ; bloginfo('name'); }
elseif (is_single() ) { single_post_title();}
elseif (is_page() ) { bloginfo('name'); echo ': '; single_post_title();}
else { wp_title('',true); } ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/nav.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/print.css" type="text/css" media="print" />

<!--[if IE]>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/ie.css" type="text/css" />
<![endif]-->

<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/jd.gallery.css" type="text/css" media="screen" charset="utf-8"/>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/mootools.v1.11.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jd.gallery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/dropdowns.js"></script>


<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<?php 
	// IE6 killer :D
	if (get_option('openbook_kill_ie6') != 'false') {
		echo "<!--[if IE 6]><style>*{position:relative}</style><table><input></table><![endif]-->";
	}
?>

<?php wp_head(); ?>
</head>
<body<?php if ( is_home() ) { ?> id="home"<?php } ?>>

<div id="topmenu">
	<div id="cen">
		<?php wp_nav_menu(array('theme_location' => 'top-menu'));  ?> 
	</div><!--/cen-->
</div><!--/topmenu-->
		
<div id="page" class="clearfloat">
<div id="header">
<div class="clearfloat">
<div id="branding" class="left">
<a href="<?php echo get_option('home'); ?>">
<?php if(get_option('openbook_logo_url') !="") {
       echo '<img src="'.get_option('openbook_logo_url').'" alt="" id="logo" />';
} else { ?>       
<img src="<?php echo get_option('template_url'); ?>/images/logo.jpg" alt="" id="logo"/>
<?php } ?>
</a>
</div>

<?php include (TEMPLATEPATH . '/searchform.php'); ?>

</div>

<?php wp_nav_menu(array('theme_location' => 'main-menu')); ?> 

<div class="ie6clear"></div>
<?php if (!is_home() ) { ?>
	<div id="shadow"></div>

<?php } else { ?>


<div id="head-news">
<h3>Latest posts</h3>
<?php query_posts('showposts=7'); ?>
<ul>
  <?php while (have_posts()) : the_post(); ?>
          <li><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a> (<?php comments_number('0','1','%')?>)</li>
<?php endwhile; ?>
</ul>
<span>&raquo; <a href="archives/">Archives</a></span>
</div><!--/head-news-->
	
<div id="myGallery">
    <?php 
    $galleryposts = get_option('openbook_featured_posts')+1;
    $gallerycat = get_option('openbook_featured_cat');
    query_posts('showposts='.$galleryposts.'&cat='.$gallerycat); ?>
    <?php while (have_posts()) : the_post(); ?>
	<div class="imageElement">
		<h3><?php the_title(); ?></h3>
		<?php the_excerpt(); ?>
		<a href="<?php the_permalink() ?>" title="Read more" class="open"></a>
		<?php $values = get_post_custom_values("featuredimg"); ?>
	        <img src="<?php $values = get_post_custom_values("featuredimg"); echo $values[0]; ?>" class="full" alt="<?php the_title(); ?>"/>
		<img src="<?php $values = get_post_custom_values("featuredimg"); echo $values[0]; ?>" class="thumbnail" alt="<?php the_title(); ?>"/>
	</div>
    <?php endwhile; ?>
</div><!--/myGallery-->



<?php } ?>
<div class="clear"></div>
</div><!-- /header -->

