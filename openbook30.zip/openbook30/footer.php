<hr id="fuck-ie" />
</div>
	<div id="footer">
		<?php wp_footer(); ?>
	</div><!-- #footer -->
</body>
</html>
