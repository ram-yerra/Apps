<?php get_header(); ?>
 

<div id="content">
  <div id="leftcol">
	<?php
	$display_categories = explode(',',stripslashes(get_option('openbook_left_col')));
	foreach ($display_categories as $category) { ?>
	    <div class="clearfloat">
		<?php
       		$showposts = get_option('openbook_posts_per_cat');	
		query_posts("showposts=$showposts&cat=$category");
        	$wp_query->is_category = false;
                $wp_query->is_archive = false;
                $wp_query->is_home = true;
                 ?>
      <h3><span><a href="<?php echo get_category_link($category);?>"><?php
          single_cat_title(); ?></a></span></h3>
      <?php while (have_posts()) : the_post(); ?>
<h5><a href="<?php the_permalink() ?>" rel="bookmark" class="title"><?php the_title(); ?></a></h5>
<?php
        $values = get_post_custom_values("Image");
        if (isset($values[0])) {
?>
	<a href="<?php the_permalink() ?>" rel="bookmark"><img src="<?php $values = get_post_custom_values("Image"); echo $values[0]; ?>" alt="<?php the_title(); ?>" /></a>
      <?php } ?>
      
      <?php the_excerpt(); ?>
      <?php endwhile; ?>
    </div>
    <?php } ?>
  </div><!--END LEFTCOL-->
  
  
  <div id="rightcol">
    <?php
$display_categories = explode(',',stripslashes(get_option('openbook_right_col')));
foreach ($display_categories as $category) { ?>
    <div class="clearfloat">
	<?php 
	$showposts = get_option('openbook_posts_per_cat');	
	query_posts("showposts=$showposts&cat=$category");
	    $wp_query->is_category = false;
		$wp_query->is_archive = false;
		$wp_query->is_home = true;
		 ?>
      <h3><span><a href="<?php echo get_category_link($category);?>"><?php single_cat_title(); ?></a></span></h3>
      <?php while (have_posts()) : the_post(); ?>
	 <h5><a href="<?php the_permalink() ?>" rel="bookmark" class="title"><?php the_title(); ?></a></h5>
      <?php
// this grabs the image filename
	$values = get_post_custom_values("Image");
// this checks to see if an image file exists
	if (isset($values[0])) {						
?>
      <a href="<?php the_permalink() ?>" rel="bookmark"><img src="<?php $values = get_post_custom_values("Image"); echo $values[0]; ?>" alt="" /></a>
      <?php } ?>
      <?php the_excerpt(); ?>
      <?php endwhile; ?>
    </div>
    <?php } ?>
  </div><!--END RIGHTCOL-->
</div><!--END CONTENT-->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
