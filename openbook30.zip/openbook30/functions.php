<?php
/* Fonctions d'administration ********************************************/

add_action('admin_menu', 'openbook_add_theme_page');

function openbook_init() {
	add_option('openbook_logo_url',get_option('home').'/wp-content/themes/openbook-fr/images/lyxia.png');
	add_option('openbook_featured_posts', 6);		
	add_option('openbook_left_col', 'blaaaa');
	add_option('openbook_right_col', 1);
	add_option('openbook_posts_per_cat', 2);
	add_option('openbook_featured_cat', 0);
	add_option('openbook_about_text', 'bla bla bla');
	add_option('openbook_kill_ie6', 'false');
}

function openbook_add_theme_page() {
	if(get_option('openbook_featured_cat') == '') {
		openbook_init();
	}
	
	if ($_GET['page'] == basename(__FILE__)) {
		if ( 'save' == $_REQUEST['action'] ) {
			//jbj starts 
			if(isset($_REQUEST['openbook_logo_url'])) {
				update_option('openbook_logo_url', $_REQUEST['openbook_logo_url']);
			} 

			if(isset($_REQUEST['openbook_featured_posts'])) {
				update_option('openbook_featured_posts', $_REQUEST['openbook_featured_posts']);
			}

			if(isset($_REQUEST['openbook_left_col'])) {
				update_option('openbook_left_col', $_REQUEST['openbook_left_col']);
			} else	update_option('openbook_left_col', '1,2,3');

			if(isset($_REQUEST['openbook_right_col'])) {
				update_option('openbook_right_col', $_REQUEST['openbook_right_col']);
			} else	update_option('openbook_right_col', '1,2,3');

			if(isset($_REQUEST['openbook_posts_per_cat'])) {
				update_option('openbook_posts_per_cat', $_REQUEST['openbook_posts_per_cat']);
			} //else	update_option('openbook_right_col', '1,2,3');
		
			if(isset($_REQUEST['openbook_featured_cat'])) {
				update_option('openbook_featured_cat', $_REQUEST['openbook_featured_cat']);
			} else	update_option('openbook_featured_cat', 'A propos');	
			
			if(isset($_REQUEST['openbook_about_text'])) {
				update_option('openbook_about_text', $_REQUEST['openbook_about_text']);
			} else	update_option('openbook_about_text', '');

			if(isset($_REQUEST['openbook_kill_ie6'])) {
				update_option('openbook_kill_ie6', 'true');
			} else	update_option('openbook_kill_ie6', 'false');
			
			header("Location: themes.php?page=functions.php&saved=true");
			die;			
		}
		add_action('admin_head', 'openbook_theme_page_head');
	}
	add_theme_page('Openbook Options', 'OpenBook', 'edit_themes', basename(__FILE__), 'openbook_theme_page');
} 

function openbook_theme_page_head() { ?>

	<style type="text/css">
		div#openbook-div {
			display: block;
		}
		div#openbookCaption {
			border-top: 1px solid #0d324f;
			margin: 10px 20px 0px 10px;
			padding: 10px;
			text-align: center;
		}
		div#openbookCaption p {
			text-align: center;
		}
		img#openbookLogo {
			border: 0; margin: 0; padding: 0;
			display: block;
			width: 174px; height: 51px;
			text-decoration: none;
		}
	</style>

<?php
} // end openbook theme page head
add_action('wp_footer', 'cr');
function openbook_theme_page() {
	if ( $_REQUEST['saved'] ) echo '<div id="message" class="updated fade"><p><strong>Options updated!</strong></p></div>';
?>
<div class="wrap">
	<div id="openbook-div">
		<h2>OpenBook Options</h2>
   <p>On this page, you can define options for your <a href="http://www.webdevcat.com">OpenBook</a> theme, like your logo url or the categories to display on your homepage.</p>
		<form name="openbook" method="post" action="<?php $_SERVER['REQUEST_URI']; ?>">
			<input type="hidden" name="action" value="save" />
			<table class="optiontable">
				<tbody>
				<!-- jbj starts -->
				<tr>
					<th>Logo url:</th>
					<td>
					<input name="openbook_logo_url" type="text" class="code" value="<?php echo(stripslashes(get_option('openbook_logo_url'))); ?>" /></td>
				</tr>
				<tr>
					<th><em>Featured</em> categorie ID:</th>
					<td><input name="openbook_featured_cat" type="text" class="code" value="<?php echo(get_option('openbook_featured_cat')); ?>" /></td>
				</tr>
				<tr>
					<th>Number of posts to display on SmoothGallery:</th>
					<td>
					<?php $nb_posts = get_option('openbook_featured_posts'); ?>
					<select name="openbook_featured_posts" class="code">
						<?php for($i=1;$i<31;$i++) { 
							if ($i == $nb_posts) {
								echo '<option value="'.$i.'" selected="selected">'.$i.'</option>';
							} else {
								echo '<option value="'.$i.'">'.$i.'</option>';
							}
								
						} ?>
					</td>
				</tr>
				<tr>
					    <th>Categories to display on left column:</th>
					<td>
					<input name="openbook_left_col" type="text" class="code" value="<?php echo(stripslashes(get_option('openbook_left_col'))); ?>" /></td>
				</tr>
				<tr><td colspan="2"><small>Coma separated. Exemple: <em>1,2,3</em></small></td></tr>
				<tr>
					<th>Categories to display on left column:</th>
					<td>
					<input name="openbook_right_col" type="text" class="code" value="<?php echo(stripslashes(get_option('openbook_right_col'))); ?>" /></td>
				</tr>
				<tr><td colspan="2"><small>Coma separated. Exemple: <em>1,2,3</em></small></td></tr>
				<tr>
					    <th>Number of posts to display on homepage, by category:</th>
					<td>
					<?php $nb_col = get_option('openbook_posts_per_cat'); ?>
					<select name="openbook_posts_per_cat" class="code">
						<?php for($i=1;$i<11;$i++) { 
							if ($i == $nb_col) {
								echo '<option value="'.$i.'" selected="selected">'.$i.'</option>';
							} else {
								echo '<option value="'.$i.'">'.$i.'</option>';
							}
								
						} ?>
					</td>
				</tr>	
			
				<tr>
				<tr>
					<th>Kill IE6?:</th>
						<td>
							<label for="openbook_kill_ie6">
							<input type="checkbox" name="openbook_kill_ie6" id="openbook_kill_ie6" <?php if(get_option('openbook_kill_ie6') == 'true') { ?> checked="checked" <?php } ?>	/>
							
							</label>
						</td>
					</tr>
					<tr><td colspan="2"><small>Check this option if you want to crash any Internet Explorer 6 that will try to open your blog. :D</small></td></tr>
					<tr>
		    	</tbody>
			</table>
		<p class="submit">
			<input type="submit" name="Save" value="Save &raquo;" />
		</p>
		</form>
		
	</div>
</div>	
<?php
} // end theme page



/* End admin panel functions ****************************************/

if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
        'after_widget' => '</li>',
        'before_title' => '<h2 class="widgettitle">',
        'after_title' => '</h2>',
    )); 

function cr(){
	echo '<div id="credit">Copyright &copy; '.date("Y").' '.get_bloginfo("name").' &bull; OpenBook Theme by <a href="http://www.webdevcat.com">WebDevCat</a>.</div><!-- #credit -->';
}                                                                       

function register_my_menus() {
	register_nav_menus(
		array(
			'top-menu' => __('Top Menu'),
			'main-menu' => __('Main Menu'),
		)
	);
}
add_action('init', 'register_my_menus');


