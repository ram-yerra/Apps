<?php get_header(); ?>

	<div id="content">

	<?php if (have_posts()) : ?>

		<h1>Search results</h1>

			<?php while (have_posts()) : the_post(); ?>

			<div class="post">
    <h3><span><?php the_time('M j, Y') ?></span></h3>
				<h4 id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h4>
<small>Posted by <?php the_author_posts_link('namefl'); ?> in <?php the_category(', ') ?>
			<span class="comments-info"> &bull; <?php comments_popup_link('No comments', '1 comment', '% comments '); ?></span></small>
				
	<div class="entry">
					<?php the_excerpt() ?>
				</div>
				
			</div>

		<?php endwhile; ?>
		
		<div class="navigation">
			<?php next_posts_link('Previous entries') ?>
			<?php previous_posts_link('Next entries') ?>
		</div>

	<?php else : ?>

		<p>Sorry, nothing match your search.</p>
		

	<?php endif; ?>

	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
