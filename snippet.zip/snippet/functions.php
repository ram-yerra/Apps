<?php

// Remove default Thematic actions
function remove_thematic_actions() {
    remove_action('thematic_header','thematic_access',9);
	//remove_action('thematic_header','thematic_blogtitle',3);
	//remove_action('thematic_header','thematic_blogdescription',5);
}
add_action('wp','remove_thematic_actions');

// Create a custom access div with the menu and search box
function search_access() { ?>
   	<div id="access">
        	<?php wp_nav_menu(array( 'theme_location' => 'primary-menu' )) ?>
    </div><!-- #access -->
<?php }
add_action('thematic_header','search_access',9);
  
function register_my_menu() {
	register_nav_menu('primary-menu', __('Primary Menu'));
}
add_action('init', 'register_my_menu');

function my_footer($thm_footertext) {
	$thm_footertext = 'Copyright &copy; 2010 <a href="'.get_bloginfo("url").'">'.get_bloginfo("name").'</a>. <a href="http://www.webdevcat.com">WordPress Development</a> by WebDevCat.';
	return $thm_footertext;
}
add_filter('thematic_footertext', 'my_footer');


function childtheme_favicon() { ?>
	<link rel="shortcut icon" href="<?php echo bloginfo('stylesheet_directory') ?>/images/favicon.png" />
<?php }
add_action('wp_head', 'childtheme_favicon');

function index_loop(){
	while ( have_posts() ) : the_post() /* Start the loop: */ ?>
      <div id="post-<?php the_ID() ?>" class="home <?php thematic_post_class() ?>">
          <?php //thematic_postheader(); ?>
			<h2 class="entry-title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h2>
			<div  class="entry-meta">Published by <?php the_author(); ?> <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago'; ?> <br/> <?php comments_number('No comments yet','1 comment','% comments'); ?></div><!-- .entry-meta -->
        <div class="entry-content">
          <?php thematic_content(); ?>
        </div>
		<div class="post-bottom">
			<a href="<?php the_permalink();?>">&rarr; Continue Reading</a>
		</div>
      </div><!-- .post -->
    <?php endwhile; 
}

function remove_index_loop() {
	remove_action('thematic_indexloop', 'thematic_index_loop');
}
add_action('init', 'remove_index_loop');
add_action('thematic_indexloop', 'index_loop');

?>