<?php
include_once('../../../wp-config.php');
include_once('../../../wp-load.php');
include_once('../../../wp-includes/wp-db.php');

function insertTabs($directory){
	$error = false;
	
	//Loop through directory
	$handle = opendir($directory);
	while (false !== ($file = readdir($handle))) {
		if ($file!='.' && $file!='..' ){
			$filename = $file;
			$file = strtr($file, "-", ".");
			$pieces = explode(".", $file); //Split filename on dots
			$artist = $pieces[0];
			$songname = $pieces[1];
		
			if ($artist == '' || $songname == ''){
				$error = true;
			}
		
			//Read the file and store content in a variable
			echo "file: ".$directory."/".$filename."<br/>";
			$fullfile = $directory."/".$filename;
			$tab = '<pre class="tab">'.file_get_contents($fullfile).'</pre>';
		
			//Insert data in the DB
			$new_post = array(
		    	'post_title' => $artist.' - '.$songname,
		    	'post_content' => $tab,
		    	'post_status' => 'publish',
		    	'post_date' => date('Y-m-d H:i:s'),
		    	'post_author' => 1,
		    	'post_type' => 'post',
		    	'post_category' => array(0)
			);

			if (!$error){
				if ($post_id = wp_insert_post($new_post)) {
					echo $filename." inserted successfully.<br/>";
				}
			} else {
				echo $filename." can't be inserted.";
			}
		}
	}
}

insertTabs('tabtest');
?>