		</div><!-- data role content-->
	
		<?php wp_footer(); ?>    
	</div><!-- data role content-->
</body>
